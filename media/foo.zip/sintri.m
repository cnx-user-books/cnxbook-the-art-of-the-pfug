clf
axis off
line([0 2], [0 1]);
line([2 2], [0 1]);
line([0 2], [0 0]);